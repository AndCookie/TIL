
document.getElementById("sendBtn").addEventListener('click', validation);

function validation(e) {
   e.preventDefault();  // 기능이 있는 태그의 기본 기능을 삭제 (a, submit, reset 등)

   let inquiryForm = document.getElementById("inquiryForm");

   inquiryForm.submit();

   let message = $("#message").val();

   let sendData = {
      "message": message
   };

   log.info(sendData.toString);

   //alert(JSON.stringify(sendData));
   $.ajax({
      url: 'inquiry'
      , method: 'POST'
      , data: sendData
      , success: function(resp) {
         alert("resp")
         $("#message").text(resp["text"]);
      },
      error: function(XMLHttpRequest, textStatus, errorThrown) { // 비동기 통신이 실패할경우 error 콜백으로 들어옵니다.
         alert("통신 실패.")
      }
   })

}