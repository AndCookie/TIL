package net.kdigital.hackathon.mapper;


import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DragMapper {



}
