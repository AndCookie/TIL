package net.kdigital.hackathon.domain;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class Data1 {
   
    private String obs_time;
    private String current_direct;
    private String current_speed;

}