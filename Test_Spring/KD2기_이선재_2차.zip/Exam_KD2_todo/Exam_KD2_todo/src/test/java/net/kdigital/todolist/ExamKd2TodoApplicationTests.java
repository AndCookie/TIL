package net.kdigital.todolist;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExamKd2TodoApplicationTests {

	@Test
	void contextLoads() {
	}

}
