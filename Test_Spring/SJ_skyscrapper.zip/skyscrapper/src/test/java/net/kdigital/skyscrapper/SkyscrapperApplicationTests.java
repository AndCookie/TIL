package net.kdigital.skyscrapper;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SkyscrapperApplicationTests {

	@Test
	void contextLoads() {
	}

}
