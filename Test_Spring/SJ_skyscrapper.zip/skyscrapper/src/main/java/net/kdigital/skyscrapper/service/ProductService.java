package net.kdigital.skyscrapper.service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import lombok.extern.slf4j.Slf4j;
import net.kdigital.skyscrapper.domain.Product;
import net.kdigital.skyscrapper.mapper.ProductMapper;

@Service
@Slf4j
public class ProductService {
	
	@Autowired
	ProductMapper productMapper;
	
	/**
	 * 게시글 등록 요청
	 * @param product 제품 domain
	 * @return 
	 */
	public int insertProduct(Product product) {
		int result=productMapper.insertProduct(product);
		
		log.info(product.toString());
		
		return result;
	}

	/**
	 * 게시글 개수 요청
	 * @param searchItem
	 * @param searchWord
	 * @return
	 */
	public int getProductCount(String searchItem, String searchWord) {
		Map<String, Object> map = new HashMap<>();
		
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);
		
		int totalRecordCount = productMapper.getProductCount(map);
		
		return totalRecordCount;
	}

	
	/**
	 * 전체 상품 목록 요청
	 * @param startRecord
	 * @param endRecord
	 * @param searchItem
	 * @param searchWord
	 * @return
	 */
	public List<Product> selectProductAll(
			int srow,
			int erow,
			String searchItem,
			String searchWord) {
		
		Map<String, Object> map = new HashMap<>();
		
		map.put("srow", srow);
		map.put("erow", erow);
		map.put("searchItem", searchItem);
		map.put("searchWord", searchWord);
		
		List<Product> listproduct = productMapper.selectProductAll(map);
		
		return listproduct;
	}

	public Product selectProduct(int product_id) {
		
		Product product = productMapper.selectProduct(product_id);
		
		return product;
	}
}
